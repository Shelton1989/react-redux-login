import React from 'react';

const Footer = ()=>{
    return(
        <div id="Footer">
            <div className="container">
                <p className="footer">&copy; Shelton Wilson 2019</p>
            </div>
        </div>
    );
};

export default Footer;